/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugas_pbo_atm;

/**
 *
 * @author Acer
 */
public class Tugas_PBO_ATM {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
